const ShoppingCart = require("../shoppingCart");

describe("Shopping Cart Service", () => {
  let cart;

  beforeEach(() => {
    cart = new ShoppingCart();
  });

  test("add item to cart", () => {
    cart.addItem("Book", 100, 2);
    expect(cart.items.length).toBe(1);
  });

  test("remove item from cart", () => {
    cart.addItem("Book", 100, 2);
    cart.removeItem("Book");
    expect(cart.items.length).toBe(0);
  });

  test("calculate total price", () => {
    cart.addItem("Pen", 10, 3);
    expect(cart.calculateTotal()).toBe(30);
  });

  test("apply discount", () => {
    cart.addItem("Bag", 100, 1);
    cart.applyDiscount("SAVE10");
    expect(cart.checkout()).toBe(90);
  });

  test("calculate tax", () => {
    cart.addItem("Shoes", 100, 1);
    expect(cart.calculateTax(0.1)).toBe(10);
  });
});