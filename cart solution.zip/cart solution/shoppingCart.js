class ShoppingCart {
  constructor() {
    this.items = [];
    this.discount = 0;
  }

  // Add item to cart
  addItem(name, price, quantity) {
    this.items.push({ name, price, quantity });
  }

  // Remove item by name
  removeItem(name) {
    this.items = this.items.filter(item => item.name !== name);
  }

  // Calculate total price
  calculateTotal() {
    let total = 0;
    for (let item of this.items) {
      total += item.price * item.quantity;
    }
    return total;
  }

  // Apply discount code
  applyDiscount(code) {
    if (code === "SAVE10") this.discount = 0.10;
    else if (code === "SAVE20") this.discount = 0.20;
    else if (code === "SAVE30") this.discount = 0.30;
    else this.discount = 0;
  }

  // Calculate tax before discount
  calculateTax(taxRate) {
    return this.calculateTotal() * taxRate;
  }

  // Checkout
  checkout(taxRate = 0) {
    const total = this.calculateTotal();
    const tax = total * taxRate;
    const discountAmount = total * this.discount;

    const finalAmount = total + tax - discountAmount;

    // Clear cart
    this.items = [];
    this.discount = 0;

    return finalAmount;
  }
}

module.exports = ShoppingCart;