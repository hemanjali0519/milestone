class InventoryManager {
  constructor() {
    this.products = [];
  }

  // Add product
  addProduct(product) {
    const exists = this.products.find(
      p => p.productID === product.productID
    );
    if (exists) {
      throw new Error("Product already exists");
    }
    this.products.push(product);
  }

  // Get product by ID
  getProductById(productID) {
    return this.products.find(p => p.productID === productID) || null;
  }

  // Update product
  updateProduct(productID, updatedData) {
    const product = this.products.find(p => p.productID === productID);
    if (!product) {
      throw new Error("Product not found");
    }
    Object.assign(product, updatedData);
  }

  // Delete product
  deleteProduct(productID) {
    const index = this.products.findIndex(
      p => p.productID === productID
    );
    if (index === -1) {
      throw new Error("Product not found");
    }
    this.products.splice(index, 1);
  }

  // List all products
  listAllProducts() {
    return this.products;
  }
}

module.exports = InventoryManager;